<?php 
  include('layouts/header.php'); 
  require_once('controllers/ConnectionManager.php'); 

  $connectionManager = new ConnectionManager();
  $connection = $connectionManager->getConnection();

  function truncateString($text, $maxLength) {
    if (strlen($text) > $maxLength) {
        $text = substr($text, 0, $maxLength) . '...';
    }
    return $text;
}
?>


    <!-- Product container --> 
    <div class="product-container row mt-5">
        <?php

        if (isset($_GET['cata'])) {
            $category = $_GET['cata'];
        
            if ($connection) {
                //$sql = "SELECT * FROM `products` WHERE product_category='$category'";
                $sql = "SELECT * FROM `products` WHERE product_category=$category";
                $result = mysqli_query($connection, $sql);
        
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {

                        $first10Words = truncateString($row['product_description'], 60);
                        //echo $first10Words;
                        //die();

                        ?>
                        <div class="product-card col-4">
                            <img class="product-image" src="images/product_images/<?php echo $row['product_image']; ?>" alt="Product Image">
                            <div class="product-details">
                                <div class="product-title"><?php echo $row['product_name']; ?></div>
                                <div class="product-price">$<?php echo number_format($row['product_price'], 2); ?></div>
                                <div class="product-title"><?php echo ($row['product_quantity']>0)?'In stock':'Out of stock'; ?></div>
                                <div class="product-description"><?php echo $first10Words; ?></div>
                                <a class="add-to-cart-button" href="product.php?id=<?php echo $row['product_id']; ?>">Add to Cart</a>
                            </div>
                        </div>
                        <?php
                    }
        
                    mysqli_free_result($result);
                } else {
                    echo "Error executing query: " . mysqli_error($connection);
                }
        
                mysqli_close($connection);
            } else {
                echo "Database connection failed.";
            }
        }
        

        ?>
    </div>



    
<?php include('layouts/footer.php'); ?>