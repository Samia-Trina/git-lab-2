
<?php 
    include('layouts/header.php');
?>



                <div class="add-product">
                    <h2>Add Product</h2>
                    <?php
                        // Check for login error message
                        if (isset($_GET['addsucc'])) {
                            $addsucc = $_GET['message'] ?? 'product added successfully!';
                            echo '<div class="demo_alert alert alert-success">' . htmlspecialchars($addsucc) . '</div>';
                        }
                    ?>
                    <form action="../controllers/Admin_product_controller.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="product-name">Product Name</label>
                            <input type="text" class="form-control" id="product-name" name="product_name" required>
                        </div>
                        <div class="form-group">
                            <label for="product-description">Description</label>
                            <textarea class="form-control" id="product-description" name="product_description" rows="4" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="product-price">Price</label>
                            <input type="number" step="0.01" class="form-control" id="product-price" name="product_price" required>
                        </div>
                        <div class="form-group">
                            <label for="product-image">Product Quantity</label>
                            <input type="number" class="form-control-file" id="product-quantity" name="product_quantity" required>
                        </div>
                        <div class="form-group">
                            <label for="product-image">Product Image</label>
                            <input type="file" class="form-control-file" id="product-image" name="product_image" accept="image/*" required>
                        </div>
                        <div class="form-group">
                            <label for="product-category">Category</label>
                            <select class="form-control" id="product-category" name="product_category" required>
                                <option value="Single">Single</option>
                                <option value="Double">Double</option>
                                <option value="Combo">Combo Pack</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="product-discount">Discount</label>
                            <input type="number" step="0.01" class="form-control" id="product-discount" name="product_discount">
                        </div>
                        <button type="submit" name="addproductbtn" class="btn btn-primary">Save Product</button>
                    </form>
                </div> 
                            

    <script>
        let demo_alert = document.getElementsByClassName('demo_alert')[0];

        setTimeout(() => {
            demo_alert.style.display = 'none';
        }, 2000);
    </script>
                 
<?php 
    include('layouts/footer.php');
?>