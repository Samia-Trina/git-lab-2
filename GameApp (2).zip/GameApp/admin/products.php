<?php
    include('layouts/header.php');
    include_once('../controllers/ConnectionManager.php'); 

    $connectionManager = new ConnectionManager();
    $connection = $connectionManager->getConnection();

    if ($connection) {
        if (isset($_POST['remove_product']) && isset($_POST['product_id'])) {
            $productId = $_POST['product_id'];

            $sql = "DELETE FROM products WHERE product_id = $productId";
            $result = mysqli_query($connection, $sql);

            if ($result) {
                header('Location: products.php?removesuccess');
                exit();
            } else {
                header('Location: products.php?removefailed');
                exit(); 
            }
        }
    } else {
        header('Location: products.php?connectionfailed');
        exit(); 
    }

?>


                <div class="product-list">
                    <h2>Product List</h2>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Availability</th>
                                <th>Category</th>
                                <th>Discount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php

                            if ($connection) {
                                $sql = "SELECT * FROM products";
                                $result = mysqli_query($connection, $sql);

                                if ($result) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>";
                                        ?>
                                        <td><?php echo $row['product_id']; ?></td>
                                        <td><?php echo $row['product_name']; ?></td>
                                        <td><?php echo $row['product_description']; ?></td>
                                        <td>$<?php echo number_format($row['product_price'], 2); ?></td>
                                        <td><?php echo ($row['product_availability'] == 1 ? 'In Stock' : 'Out of Stock'); ?></td>
                                        <td><?php echo $row['product_category']; ?></td>
                                        <td><?php echo $row['product_discount']; ?>%</td>
                                        <td>
                                            <form method="post" action="products.php">
                                                <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                                                <button type="submit" name="remove_product" class="btn btn-danger">Remove</button>
                                            </form>
                                        </td>
                                        <?php
                                        echo "</tr>";
                                    }                                    
                                    mysqli_free_result($result);
                                } else {
                                    echo "Error executing query: " . mysqli_error($connection);
                                }

                                mysqli_close($connection);
                            } else {
                                echo "Database connection failed.";
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
                
                
                        
<?php 
    include('layouts/footer.php');
?>