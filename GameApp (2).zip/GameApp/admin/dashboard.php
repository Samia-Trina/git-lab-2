<?php 
    include('layouts/header.php');
    include_once('../controllers/ConnectionManager.php');

    $connectionManager = new ConnectionManager();
    $connection = $connectionManager->getConnection();

    if ($connection) {
        // Fetch total sales
        $sqlTotalSales = "SELECT SUM(total_price) AS total_sales FROM orders";
        $resultTotalSales = mysqli_query($connection, $sqlTotalSales);
        if ($resultTotalSales && mysqli_num_rows($resultTotalSales) > 0) {
            $rowTotalSales = mysqli_fetch_assoc($resultTotalSales);
            $totalSales = $rowTotalSales['total_sales'];
        }

        // Fetch total users
        $sqlTotalUsers = "SELECT COUNT(id) AS total_users FROM registration";
        $resultTotalUsers = mysqli_query($connection, $sqlTotalUsers);
        if ($resultTotalUsers && mysqli_num_rows($resultTotalUsers) > 0) {
            $rowTotalUsers = mysqli_fetch_assoc($resultTotalUsers);
            $totalUsers = $rowTotalUsers['total_users'];
        }

        // Fetch total orders
        $sqlTotalOrders = "SELECT COUNT(id) AS total_orders FROM orders";
        $resultTotalOrders = mysqli_query($connection, $sqlTotalOrders);
        if ($resultTotalOrders && mysqli_num_rows($resultTotalOrders) > 0) {
            $rowTotalOrders = mysqli_fetch_assoc($resultTotalOrders);
            $totalOrders = $rowTotalOrders['total_orders'];
        }

        // Fetch total products
        $sqlTotalProducts = "SELECT COUNT(product_id) AS total_products FROM products";
        $resultTotalProducts = mysqli_query($connection, $sqlTotalProducts);
        if ($resultTotalProducts && mysqli_num_rows($resultTotalProducts) > 0) {
            $rowTotalProducts = mysqli_fetch_assoc($resultTotalProducts);
            $totalProducts = $rowTotalProducts['total_products'];
        }

        // Fetch monthly sales data (adjust query accordingly)
        $sqlMonthlySales = "SELECT MONTH(order_date) AS month, SUM(total_price) AS monthly_sales FROM orders GROUP BY MONTH(order_date)";
        $resultMonthlySales = mysqli_query($connection, $sqlMonthlySales);
        while ($rowMonthlySales = mysqli_fetch_assoc($resultMonthlySales)) {
            $monthlySalesData[$rowMonthlySales['month']] = $rowMonthlySales['monthly_sales'];
        }

        // Fetch user growth data using the correct column name
        $sqlUserGrowth = "SELECT MONTH(registration_date) AS month, COUNT(id) AS new_users FROM registration GROUP BY MONTH(registration_date)";
        $resultUserGrowth = mysqli_query($connection, $sqlUserGrowth);
        while ($rowUserGrowth = mysqli_fetch_assoc($resultUserGrowth)) {
            $userGrowthData[$rowUserGrowth['month']] = $rowUserGrowth['new_users'];
        }


?>

    <div class="dashboard-stats d-flex">
        <div class="stat-card">
            <h4>Total Sales</h4>
            <p><?php echo $totalSales; ?></p>
        </div>
        <div class="stat-card">
            <h4>Total Users</h4>
            <p><?php echo $totalUsers; ?></p>
        </div>
        <div class="stat-card">
            <h4>Total Orders</h4>
            <p><?php echo $totalOrders; ?></p>
        </div>
        <div class="stat-card">
            <h4>Total Products</h4>
            <p><?php echo $totalProducts; ?></p>
        </div>
    </div>

    <div class="graph-container">
        <canvas id="salesGrowthChart" width="400" height="200"></canvas>
    </div>

    <div class="graph-container">
        <canvas id="userGrowthChart" width="400" height="200"></canvas>
    </div>


<?php include('layouts/footer.php'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<script>
    var salesGrowthData = <?php echo json_encode($monthlySalesData); ?>;
    var salesGrowthChart = new Chart(document.getElementById('salesGrowthChart'), {
        type: 'line',
        data: {
            labels: /* Array of labels (e.g., months) */,
            datasets: [{
                label: 'Monthly Sales',
                data: salesGrowthData,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });


    var userGrowthData = <?php echo json_encode($userGrowthData); ?>;
    var userGrowthChart = new Chart(document.getElementById('userGrowthChart'), {
        type: 'line',
        data: {
            labels: /* Array of labels (e.g., months) */,
            datasets: [{
                label: 'User Growth',
                data: userGrowthData,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
            // Additional chart options
        }
    });
</script>
<?php 
    } else {
        echo "Database connection failed.";
    }
?>
