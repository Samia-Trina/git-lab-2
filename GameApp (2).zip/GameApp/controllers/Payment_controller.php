<?php
    session_start();
    include_once('ConnectionManager.php');

    $connectionManager = new ConnectionManager();
    $con = $connectionManager->getConnection();


    // Check if the 'payments' table exists, if not, create it
    $paymentTableExists = $con->query("SHOW TABLES LIKE 'payments'");
    if ($paymentTableExists->num_rows == 0) {
        $createPaymentTableSQL = "CREATE TABLE IF NOT EXISTS payments (
            payment_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT,
            first_name VARCHAR(255) NOT NULL,
            last_name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            address VARCHAR(255) NOT NULL,
            city VARCHAR(255) NOT NULL,
            state VARCHAR(255) NOT NULL,
            zip VARCHAR(10) NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            phone_number VARCHAR(20) NOT NULL,
            transaction_id VARCHAR(255) NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id)
        )";
        $con->query($createPaymentTableSQL);
    }

    if (isset($_POST['order_id'])) {
        $order_id = $_POST['order_id'];
        $first_name = $_POST['firstName'];
        $last_name = $_POST['lastName'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $zip = $_POST['zip'];
        $payment_method = $_POST['paymentMethod'];
        $phone_number = $_POST['phoneNumber'];
        $transaction_id = $_POST['transactionId'];
        $amount = $_POST['amount'];

        // Insert payment data into the 'payments' table
        $insertPaymentSQL = "INSERT INTO payments (order_id, first_name, last_name, email, address, city, state, zip, payment_method, phone_number, transaction_id, amount)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($insertPaymentSQL);
        $stmt->bind_param("issssssssssd", $order_id, $first_name, $last_name, $email, $address, $city, $state, $zip, $payment_method, $phone_number, $transaction_id, $amount);
        
        if ($stmt->execute()) {
            $updateOrderStatusSQL = "UPDATE orders SET status = 'paid' WHERE id = ?";
            $stmt = $con->prepare($updateOrderStatusSQL);
            $stmt->bind_param("i", $order_id);
            $stmt->execute();
            
            header("Location: ../profile.php");
            exit();
        } else {
            header("Location: payment.php?failedpayment");
            exit();
        }
    }

?>
