<?php
    require_once 'ConnectionManager.php';
    session_start();

    $usernameErr = $emailErr = $passwordErr = $confirmPasswordErr = "";
    $username = $email = $password = $confirmPassword = "";

    if (isset($_POST['regis_btn'])) {

        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $confirmPassword = $_POST["confirmPassword"];


        function validateInput($input, $pattern) {
            return preg_match($pattern, $input);
        }


        if (empty($_POST["username"])) {
            $usernameErr = "Username is required";
        } 

        if (empty($_POST["email"])) {
            $emailErr = "Email is required";
        } else {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailErr = "Invalid email format";
            }
        }

        // Validate password (required field, minimum length)
        if (empty($_POST["password"])) {
            $passwordErr = "Password is required";
        } else {
            $password = $_POST["password"];
            if (strlen($password) < 8) {
                $passwordErr = "Password must be at least 8 characters long.";
            }
        }


        if (empty($_POST["confirmPassword"])) {
            $confirmPasswordErr = "Confirm Password is required";
        } else {
            if ($confirmPassword !== $password) {
                $confirmPasswordErr = "Passwords do not match";
            }
        }


        // If all validations pass, proceed with registration
        if (empty($usernameErr) && empty($emailErr) && empty($passwordErr) && empty($confirmPasswordErr)) {

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $connectionManager = new ConnectionManager();
            $conn = $connectionManager->getConnection();

            $checkTableQuery = "SHOW TABLES LIKE 'registration'";
            $result = mysqli_query($conn, $checkTableQuery);

            if (!$result) {
                echo "Error checking for table: " . mysqli_error($conn);
            } else {
                if (mysqli_num_rows($result) == 0) {
                    $createTableQuery = "CREATE TABLE registration (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        username VARCHAR(255) UNIQUE NOT NULL,
                        email VARCHAR(255) UNIQUE NOT NULL,
                        password VARCHAR(255) NOT NULL,
                        registration_date DATE DEFAULT CURDATE()
                    )";
                    
                    
                    if (mysqli_query($conn, $createTableQuery)) {
                        echo 'Table created successfully';
                    } else {
                        echo "Error creating table: " . mysqli_error($conn);
                    }
                }

                // Insert user data into the registration table
                $insertQuery = "INSERT INTO registration (username, email, password) VALUES (?, ?, ?)";
                $stmt = mysqli_prepare($conn, $insertQuery);
                mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashedPassword);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: ../login.php?reg_suc_alert");
                    exit();
                } else {
                    echo "Error inserting data: " . mysqli_error($conn);
                }

                mysqli_stmt_close($stmt);
            }

            mysqli_close($conn);
        }else{

            //echo $usernameErr.'::::::::'.$emailErr.'::::::::::::'.$passwordErr.'::::::::::::'.$confirmPasswordErr;
            header("Location: ../registration.php?reg_err=1&usernameErr=$usernameErr&emailErr=$emailErr&passwordErr=$passwordErr&confirmPasswordErr=$confirmPasswordErr");
        }
    }


    if(isset($_POST['login_btn'])){
        $username = $_POST["username"];
        $pass = $_POST["password"];

        $connectionManager = new ConnectionManager();
        $conn = $connectionManager->getConnection();

        $selectQuery = "SELECT * FROM `registration` WHERE username=?";
        $stmt = mysqli_prepare($conn, $selectQuery);
        mysqli_stmt_bind_param($stmt, "s", $username);

        if (mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result)) {
                $hashedPassword = $row['password'];

                if (password_verify($pass, $hashedPassword)) {
                    $_SESSION['username'] = $row['username']; 
                    header("Location: ../index.php");
                    exit();
                } else {
                    $loginErr = "Incorrect username or password";
                }
            } else {
                $loginErr = "User not found";
            }
        } else {
            echo "Error executing query: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);

        if (isset($loginErr)) {
            header("Location: ../login.php?login_err=1&message=$loginErr");
            exit();
        }
    }


    if (isset($_GET['logout'])) {
        unset($_SESSION['username']); 
        header("Location: ../login.php"); 
        exit();
    }
























































?>
