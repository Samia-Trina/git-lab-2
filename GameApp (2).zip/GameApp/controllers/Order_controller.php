<?php
    session_start();
    include_once('ConnectionManager.php');

    $connectionManager = new ConnectionManager();
    $con = $connectionManager->getConnection();

    function createOrderTable($connection) {
        $sql = "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            pid INT NOT NULL,
            customer_username VARCHAR(255) NOT NULL,
            quantity INT NOT NULL,
            total_price DECIMAL(10, 2) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'unpaid',
            order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";

        if (mysqli_query($connection, $sql)) {
            return true;
        } else {
            return false;
        }
    }


    function updateQuantity($conn, $pid, $quantity) {
        
        $dbQuantity = checkAvailability($conn, $pid);
        $updateQuantity = $dbQuantity-$quantity;

        try {
            $query = "UPDATE `products` SET `product_quantity`=? WHERE product_id=?";
            $stmt = $conn->prepare($query);
    
            if ($stmt) {
                $stmt->bind_param('si', $updateQuantity, $pid); 
                $stmt->execute();
    
                $stmt->close();
                return true; 
    
            } else {
                throw new Exception("Statement preparation failed.");
            }
        } catch (Exception $e) {
            return false;
        }
    }
    


    function insertOrder($connection, $pid, $customer_username, $quantity, $total_price) {
        $sql = "INSERT INTO orders (pid, customer_username, quantity, total_price) 
                VALUES ('$pid', '$customer_username', '$quantity', '$total_price')";

        if (mysqli_query($connection, $sql)) {
            return true;
        } else {
            return false;
        }
    }


    function checkAvailability($conn, $pid) {
        try {
            $query = "SELECT product_quantity FROM `products` WHERE product_id = ?";
            $stmt = $conn->prepare($query);
    
            if ($stmt) {
                $stmt->bind_param('s', $pid);
                $stmt->execute();
    
                $stmt->bind_result($product_quantity);
                $stmt->fetch();
                $stmt->close();
                return $product_quantity;

            } else {
                throw new Exception("Statement preparation failed.");
            }
        } catch (Exception $e) {
            return -1;
        }
    }

    if (isset($_POST['orderbtn'])) {
        $product_id = $_POST['product_id'];
        $quantity = $_POST['quantity'];
        $price = urldecode($_POST['price']);
        $price = str_replace(',', '', $price);


        if(checkAvailability($con,$product_id) - $quantity < 0) {
            header("location: ../product.php?outofquontity&id=$product_id");
            die();
            //echo 'out of stock '.checkAvailability($con,$product_id);
        }

        if ($con) {
            if (!createOrderTable($con)) {
                echo 'Error creating the orders table: ' . mysqli_error($con);
                exit();
            }

            $total_price = $quantity * $price; 
            $customer_username = $_SESSION['username'];

            if (insertOrder($con, $product_id, $customer_username, $quantity, $total_price)) {
                $order_id = mysqli_insert_id($con);
                //...
                updateQuantity($con, $product_id, $quantity);
                header("location: ../payment.php?order_id=$order_id&total_payment=$total_price");
            } else {
                echo 'Failed to place the order: ' . mysqli_error($con);
            }
        } else {
            echo 'Database connection failed.';
        }
    } else {
        echo 'Missing parameters in the URL.';
    }


    mysqli_close($con);
?>
