<?php

    require_once('ConnectionManager.php'); 


    function createProductTable() {
        $connectionManager = new ConnectionManager();
        $connection = $connectionManager->getConnection();
    
        if ($connection) {
            $tableName = 'products'; // Change this to your table name
            $sql = "CREATE TABLE IF NOT EXISTS $tableName (
                product_id INT AUTO_INCREMENT PRIMARY KEY,
                product_name VARCHAR(255) NOT NULL,
                product_description TEXT NOT NULL,
                product_price DECIMAL(10, 2) NOT NULL,
                product_quantity INT NOT NULL,
                product_image VARCHAR(255) NOT NULL,
                product_category VARCHAR(255) NOT NULL,
                product_discount DECIMAL(10, 2)
            )";
    
            if (mysqli_query($connection, $sql)) {
                echo "Product table created or already exists.";
            } else {
                echo "Error creating table: " . mysqli_error($connection);
            }
    
            mysqli_close($connection);
        } else {
            echo "Database connection failed.";
        }
    }

    createProductTable();

    if (isset($_POST['addproductbtn'])) {
       
        $product_name = $_POST['product_name'];
        $product_description = $_POST['product_description'];
        $product_price = $_POST['product_price'];
        $product_quantity = $_POST['product_quantity'];
        $product_image = $_FILES['product_image']['name'];
        $product_category = $_POST['product_category'];
        $product_discount = $_POST['product_discount'];


        $connectionManager = new ConnectionManager();
        $connection = $connectionManager->getConnection();

        if ($connection) {

            $uploadDir = "../images/product_images/"; 
            $uploadPath = $uploadDir . $product_image;


            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $uploadPath)) {

                $sql = "INSERT INTO products (product_name, product_description, product_price, product_quantity, product_image, product_category, product_discount) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($connection, $sql);

                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "ssdissd", $product_name, $product_description, $product_price, $product_quantity, $product_image, $product_category, $product_discount);

                    if (mysqli_stmt_execute($stmt)) {
                        //echo "Product added successfully.";
                        header('location: ../admin/add_product.php?addsucc');
                    } else {
                        header('location: ../admin/add_product.php?adderr');
                        //echo "Error adding product: " . mysqli_error($connection);
                    }

                    mysqli_stmt_close($stmt);
                } else {
                    echo "Error preparing statement: " . mysqli_error($connection);
                }
            } else {
                echo "File upload failed.";
            }

            mysqli_close($connection);
        } else {
            echo "Database connection failed.";
        }
    }












?>
