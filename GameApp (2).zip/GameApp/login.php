<?php include('layouts/header.php'); ?>

<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-6 left-image d-flex justify-content-center align-items-center">
            <img class="registration-image" src="images/registration.png">
        </div>
        <div class="col-md-6 d-flex align-items-center">
            <div class="container">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Login</h3>
                    </div>
                    <div class="card-body">
                        <?php
                        // Check for login error message
                        if (isset($_GET['login_err'])) {
                            $errorMessage = $_GET['message'] ?? 'Login failed. Please try again.';
                            echo '<div class="demo_alert alert alert-danger">' . htmlspecialchars($errorMessage) . '</div>';
                        }
                        ?>
                        <form method="POST" action="controllers/Authentication.php">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" name="username" id="username" placeholder="Enter your username" required>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required>
                            </div>

                            <div class="text-center">
                                <button name="login_btn" type="submit" class="btn btn-primary">Login</button>
                            </div>
                        </form>
                        <div class="mt-3 text-center">
                            <p>I do not have an account. <a style="color: orange;" href="registration.php">Sign Up Here</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let demo_alert = document.getElementsByClassName('demo_alert')[0];

    setTimeout(() => {
        demo_alert.style.display = 'none';
    }, 2000);
</script>



<?php include('layouts/footer.php'); ?>
