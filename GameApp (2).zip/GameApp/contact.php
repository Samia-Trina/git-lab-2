
<?php include('layouts/header.php'); ?>


    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <?php
                    // Check for message delivery
                    if (isset($_GET['sentsucc'])) {
                        $msg = 'message sent successfully';
                        echo '<div class="demo_alert alert alert-success">' . htmlspecialchars($msg) . '</div>';
                    }
                ?>

                <h2>Contact Us</h2>
                <form method='POST' action='controllers/message_controller.php'>
                    <div class="mb-3">
                        <label for="name" class="form-label">Your Name</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Your Name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" name="message"  id="message" rows="5" placeholder="Your Message" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </div>
            <div class="col-md-6">
                <h2>Our Contact Information</h2>
                <div class="mb-3">
                    <p>
                        <strong><i class="fas fa-map-marker-alt"></i> Address:</strong> 123 Main Street, City, Country
                    </p>
                </div>
                <div class="mb-3">
                    <p>
                        <strong><i class="fas fa-envelope"></i> Email:</strong> <a href="mailto:contact@example.com">contact@example.com</a>
                    </p>
                </div>
                <div class="mb-3">
                    <p>
                        <strong><i class="fas fa-phone"></i> Phone:</strong> <a href="tel:+11234567890">+1 (123) 456-7890</a>
                    </p>
                </div>
                <div class="mb-3">
                    <p>
                        <strong><i class="far fa-clock"></i> Business Hours:</strong> Mon-Fri, 9:00 AM - 5:00 PM
                    </p>
                </div>
                <div class="mb-3">
                    <h4>Find Us on the Map:</h4>
                    <div id="map" style="height: 200px;">
                    
                    </div>
                </div>
            </div>
            
        </div>
    </div>



<script>
    let demo_alert = document.getElementsByClassName('demo_alert')[0];

    setTimeout(() => {
        demo_alert.style.display = 'none';
    }, 2000);
</script>


<?php include('layouts/footer.php'); ?>



