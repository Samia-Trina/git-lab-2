
//account card showing/hidden system  
var preLoginDiv = document.getElementById("pre-login");
var clickCount = 0;

document.getElementById("account-image").addEventListener("click", function() {
    clickCount++;

    if (clickCount % 2 === 1) {
        console.log("show");
        preLoginDiv.style.display = "block";
    } else {
        console.log("close");
        preLoginDiv.style.display = "none";
    }
});



const swiper = new Swiper('.swiper', {

    autoplay: {
        delay: 2000,
        disableOnInteraction: false,
      },


    direction: 'horizontal',

    loop: true,


    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
  

    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },

    scrollbar: {
      el: '.swiper-scrollbar',
    },
  });


  //add map apis
  let map;

  function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 123.456, lng: 123.456 }, 
        zoom: 15, 
    });
  }
  